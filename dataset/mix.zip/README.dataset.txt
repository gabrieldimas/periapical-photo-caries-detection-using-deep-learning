# Tooth Segmentation > 2025-03-01 2:33pm
https://universe.roboflow.com/gabriels/tooth-segmentation-ra8um

Provided by a Roboflow user
License: CC BY 4.0

